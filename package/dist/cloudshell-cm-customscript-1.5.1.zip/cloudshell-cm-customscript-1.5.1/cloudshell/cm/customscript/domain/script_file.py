
class ScriptFile(object):
    def __init__(self, name = None, text = None):
        self.name = name
        self.text = text